Nineteenth Hole Hotel from Wii Sports Resort ripped by DogToon64.

If used, give credit to Nintendo.

Credit to DogToon64 is optional, but would be nice.